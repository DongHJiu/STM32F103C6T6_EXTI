#ifndef __Key_H
#define __Key_H

void Key_Init(void);
int KeyOnce(void);
int KeyKeep(void);


#endif
