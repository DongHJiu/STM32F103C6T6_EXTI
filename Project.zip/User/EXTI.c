#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "Key.h"
#include "LED.h"



/**
  * @brief  外部中断和中断优先级的配置
  * @param  无
  * @retval 无
  */
void EXTI0_Init(void){
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO|RCC_APB2Periph_GPIOB,ENABLE);
	
	//GPIO的初始化已经在main函数中配置
	//下面是EXTI和NVIC的配置
	EXTI_InitTypeDef EXTIKey_Init;
	EXTIKey_Init.EXTI_Line=EXTI_Line0;                                   
	EXTIKey_Init.EXTI_LineCmd=ENABLE;
	EXTIKey_Init.EXTI_Mode=EXTI_Mode_Interrupt;                         //设置模式为中断还是事件(这里设置为中断)
	EXTIKey_Init.EXTI_Trigger=EXTI_Trigger_Falling;                     //触发中断方式(这里设置为下降沿触发)
	EXTI_Init(&EXTIKey_Init);
	
	GPIO_EXTILineConfig(GPIO_PortSourceGPIOB,GPIO_PinSource0);          //将引脚映射到外部中断上
	
	
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
	NVIC_InitTypeDef EXTI0_NVIC;
	EXTI0_NVIC.NVIC_IRQChannel=EXTI0_IRQn;
	EXTI0_NVIC.NVIC_IRQChannelCmd=ENABLE;
	EXTI0_NVIC.NVIC_IRQChannelPreemptionPriority=2;
	EXTI0_NVIC.NVIC_IRQChannelSubPriority=2;
	NVIC_Init(&EXTI0_NVIC);
}

void EXTI0_IRQHandler(void){
	LED_Data(KeyKeep());
	EXTI_ClearITPendingBit(EXTI_Line0);                                 //清除中断标志位
}
